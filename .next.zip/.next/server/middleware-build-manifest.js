globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/7af0ff2242684085.js",
      "static/chunks/a1cee12aad43c2b3.js",
      "static/chunks/turbopack-20c517f43bee4a2a.js"
    ],
    "/_error": [
      "static/chunks/fd1e1d990e52b9cf.js",
      "static/chunks/a1cee12aad43c2b3.js",
      "static/chunks/turbopack-78f816aca22d36eb.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/776cd8ae582d2314.js",
    "static/chunks/6627bc3e473b0ba3.js",
    "static/chunks/e1bbcb8cf11fa53e.js",
    "static/chunks/turbopack-ef03d5cdb3bbe81d.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];