module.exports=[86864,(a,b,c)=>{"use strict";b.exports=a.r(62342).vendored["react-ssr"].ReactDOM}];

//# sourceMappingURL=17a9d_next_dist_server_route-modules_app-page_vendored_ssr_react-dom_f67dfb4e.js.map