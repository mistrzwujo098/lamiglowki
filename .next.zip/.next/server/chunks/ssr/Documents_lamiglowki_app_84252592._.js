module.exports=[95923,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},92133,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(95923).default,width:256,height:256}}];

//# sourceMappingURL=Documents_lamiglowki_app_84252592._.js.map