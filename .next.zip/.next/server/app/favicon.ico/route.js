var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__3ce98070._.js")
R.c("server/chunks/[root-of-the-server]__0f121e0a._.js")
R.m(91693)
R.m(27191)
module.exports=R.m(27191).exports
