var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__f685101c._.js")
R.c("server/chunks/ssr/[root-of-the-server]__dbdee75a._.js")
R.m(26695)
module.exports=R.m(26695).exports
