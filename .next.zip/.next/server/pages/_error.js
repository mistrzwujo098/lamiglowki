var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/[root-of-the-server]__f685101c._.js")
R.c("server/chunks/ssr/[root-of-the-server]__dbdee75a._.js")
R.c("server/chunks/ssr/17a9d_next_91a650d8._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/17a9d_bf0329b2._.js")
R.m(71866)
module.exports=R.m(71866).exports
