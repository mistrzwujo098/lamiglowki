var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__7619fd13._.js")
R.m(45207)
module.exports=R.m(45207).exports
