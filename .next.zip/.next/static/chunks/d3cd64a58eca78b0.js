__turbopack_load_page_chunks__("/_app", [
  "static/chunks/7af0ff2242684085.js",
  "static/chunks/a1cee12aad43c2b3.js",
  "static/chunks/turbopack-20c517f43bee4a2a.js"
])
