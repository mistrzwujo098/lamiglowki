__turbopack_load_page_chunks__("/_error", [
  "static/chunks/fd1e1d990e52b9cf.js",
  "static/chunks/a1cee12aad43c2b3.js",
  "static/chunks/turbopack-78f816aca22d36eb.js"
])
